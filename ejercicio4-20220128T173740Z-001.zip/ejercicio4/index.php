<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    


    <?php
    require_once('./clases/Padre.php');
    require_once('./clases/Hijo.php');
    require_once('./clases/Hija.php');
    echo "Hola Mundo";
    echo "<br>";

    /* HERENCIA */
    /* LA CLASE PADRE NO PUEDE SER INSTANCIADA PORQUE ES ABSTRACTA */
    $padre=new Padre("nombre1",10,9.95);
    echo $padre->nombre;
    echo $padre->unidades; //no puede acceder a protected
    echo $padre->precio; //no puede acceder a private

    $hijo= new Hijo("Madrid sur","Hijo2@gmail.com");
    echo "<br>";
    $hijo->saludar("Manuel");
    /* INSTANCIAR HIJO2 */
    $hijo2= new Hijo("Valencia","Hijo2@gmail.com");
    $hijo2->datos();
    echo "<br>";
    /* CREAR VER TAREAS */
    $hijo2->verTareas("urgente");
    /* INSTANCIAR HIJA */
    $hija1=new Hija("Getafe","Hija1@gmail.com");
    $hija1->saludar("Nerea");
    $hija1->verTareas("importante");
    echo "<br>";
    /* SALUDAR SOBREESCRITURA */
    $hijo->saludar("Manuel");



    ?>
</body>
</html>