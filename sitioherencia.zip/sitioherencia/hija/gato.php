<?php
require_once('./padre/animal.php');
class gato extends animal{
    
    //FUNCION PARA MOSTRAR PROTECTED
    public function mostrarDormir(){
        $this->dormir();
    }
}