<?php
require_once('./padre/animal.php');
class perro extends animal{
    
    //FUNCION PARA MOSTRAR PROTECTED
    public function mostrarDormir(){
        $this->dormir();
    }

    //OVERRIDE
    public function comer(){
        echo "<p>Estoy comiendo huesos</p>";
    }
}