<?php
class Hija extends Padre{
    public function __construct(){
        
    }
}