<?php
abstract class Padre{

    public $nombre;
    protected $unidades;
    private $precio;
    private string $dato;
    private string $tipo;

    public function __construct(string $nombre,int $unidades, float $precio){
        $this->nombre=$nombre;
        $this->unidades=$unidades;
        $this->precio=$precio;
    }

    public function saludar($nombre){
        echo "hola, soy <i>".$nombre."</i>";
        echo "<br>";
    }

    /* METODOS */
    public function verTareas($tipo){
        if ($tipo=='urgente'){
            echo "La tarea es urgente";
        }elseif ($tipo=='importante'){
            echo "La tarea es importante";
        }else{
            echo "No hay tareas";
        }
        
    }





}

    
