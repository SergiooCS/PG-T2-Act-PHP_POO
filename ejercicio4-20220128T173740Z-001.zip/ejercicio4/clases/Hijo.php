<?php
class Hijo extends Padre{

    public $ciudad;
    public $email;

    /* public function __construct(string $ciudad){
        $this->ciudad=$ciudad;
    } */

    public function __construct(string $ciudad, string $email){
        $this->ciudad=$ciudad;
        $this->email=$email;

    }

    public function datos(){
        echo $this->ciudad;
        echo "<br>";
        echo $this->email;
    }

    /* METODO */
    public function saludar($nombre){
        echo "Nuevo metodo soy el hijo <i>".$nombre."</i>";
        echo "<br>";
    }


}
