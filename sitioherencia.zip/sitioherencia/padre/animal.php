<?php
abstract class animal{


    //METODOS
        public function comer(){
            echo "<p>Animal comiendo</p>";
        }
        protected function dormir(){
            echo "<p>Animal durmiendo</p>";
        }

}
